#include <Loader.hh>
#include <Geometry.hh>
#include <Action.hh>
#include <G4Types.hh>
#include <globals.hh>

Loader::Loader(int argc, char **argv, std::ofstream& ofsa) 
{
 this->ofs_sn=&ofsa;
 (*ofs_sn) << std::setw(12) << "Hi from Loader!" << std::endl;

 CLHEP::HepRandom::setTheEngine(new CLHEP::RanecuEngine);
 CLHEP::HepRandom::setTheSeed(time(NULL)+getpid());
 
//#ifdef G4MULTITHREADED
//    runManager = new G4MTRunManager;
//    runManager->SetNumberOfThreads(G4Threading::G4GetNumberOfCores());
//#else
 runManager = new G4RunManager;
//#endif
 runManager->SetUserInitialization(new Geometry(*this->ofs_sn));

 G4VModularPhysicsList* physicsList = new QBBC;
 physicsList->RegisterPhysics(new G4StepLimiterPhysics());
 runManager->SetUserInitialization(physicsList);
//    runManager->SetUserInitialization(new QBBC);
 runManager->SetUserInitialization(new Action(*this->ofs_sn));
 runManager->Initialize();
//    G4cout<<"G4VIS_USE="<<G4VIS_USE<<endl;
//#ifdef G4VIS_USE
    // Initialize visualization
 G4VisManager* visManager = new G4VisExecutive;
//    visManager->SetVerboseLevel(Verbose);
 visManager->Initialize();
//#endif
 G4UImanager *UImanager = G4UImanager::GetUIpointer();

 if (argc != 1) 
 {
// batch mode
  G4String command = "/control/execute ";
  G4String fileName = argv[1];
  UImanager->ApplyCommand(command + fileName);
 }
 else
 {
// interactive mode : define UI session
//#ifdef G4UI_USE
  G4UIExecutive *ui = new G4UIExecutive(argc, argv, "qt"); //Here we can redefine win32/qt interface
//     G4UIExecutive *ui = new G4UIExecutive(argc, argv, "tcsh");
     //G4UIExecutive *ui = new G4UIExecutive(argc, argv, "csh");     
//#ifdef G4VIS_USE
  UImanager->ApplyCommand("/control/execute vis.mac");
//#else
//        UImanager->ApplyCommand("/control/execute vis.mac");
//#endif
  ui->SessionStart();//and this two
  delete ui;
//#endif
  }
 }

 Loader::~Loader()
 {
  delete runManager;
  delete visManager;
  (*ofs_sn) << std::setw(12) << "Bye from Loader!" << std::endl; 
 }
